package lu.samples.sdk.client;

import org.hyperledger.fabric.sdk.HFClient;

/**
 * @TODO
 *
 * @author Emilien Charton
 * @date 14 nov. 2018
 */
public class FabricClient {

	public static FabricClient instanciate() {
		
		final FabricClient factory = new FabricClient();
		
		return factory;
	}
	
	
	public HFClient build() {
		
		
		return null;
	}
	
}
