package lu.samples.config;

import static lu.samples.config.ConfFactory.*;
import java.util.Optional;
import lu.samples.config.ConfFactory.Conf;

/**
 * @TODO
 *
 * @author Emilien Charton
 * @date 14 nov. 2018
 */
public enum Settings {
	
	USER_ADMIN_ORG1("org1Admin", conf()
									.prop("name", "admin")
									.prop("pwd", "adminPwd")
									.prop("domain", "")
									.prop("mspId", "")
									.instance()),
	
	ORDERER_ORG1("orderer.org1", conf()
									.prop("name", "orderer0.org1")	//TODO
									.prop("url", "grpc://172.31.21.208:32000") //TODO
									.instance()),
	
	PEER_ORG1("peer0.org1", conf()
								.prop("name", "")	//TODO
								.prop("url", "grpc://172.31.21.208:30001") //TODO
								.instance()),
	
	CA("org1CA", conf()
					.prop("url", "")
					.instance()),
	
	CHANNEL("channel", conf()
							.prop("name", "chnLogistic")
							.instance())
	
	;
	/**
	 * Reference on the name of setting purpose.
	 */
	private String name;
	/**
	 * Reference on the <code>Conf</code> of setting purpose.
	 */
	private Conf configuration;

	/**
	 * Default constructor.
	 */
	Settings(final String name, final Conf configuration) {
		this.name=name;
		this.configuration=configuration;
	}
	
	
	/**
	 * Accessor in reading on the name.
	 * @return the name.
	 */
	public String getName() {
		return name;
	}

	/**
	 * Accessor in reading on the configuration.
	 * @return the configuration.
	 */
	public Conf getConfiguration() {
		return configuration;
	}
	
	/**
	 * Accessor in reading on the property value.
	 * @param k The key.
	 * @return The optional value.
	 */
	public Optional<String> val(final String k) {
		
		return (configuration!=null) ? configuration.val(k) : Optional.empty();
	}
	
}
