package lu.samples.scenario;

import java.net.MalformedURLException;
import java.util.Optional;
import java.util.Properties;

import org.hyperledger.fabric.sdk.Channel;
import org.hyperledger.fabric.sdk.Orderer;
import org.hyperledger.fabric.sdk.Peer;
import org.hyperledger.fabric.sdk.Enrollment;
import org.hyperledger.fabric.sdk.HFClient;
import org.hyperledger.fabric.sdk.exception.InvalidArgumentException;
import org.hyperledger.fabric.sdk.security.CryptoSuite;
import org.hyperledger.fabric_ca.sdk.HFCAClient;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import lu.samples.config.Settings;
import lu.samples.model.UserDefault;

/**
 * @TODO
 *
 * @author Emilien Charton
 * @date 14 nov. 2018
 */
public class SimpleConnection {

	// Reference on the default logging system.
	final Logger LOG = LoggerFactory.getLogger(SimpleConnection.class);
	
	/**
	 * TODO
	 * 
	 * @param args
	 */
	public static void main(final String[] args) {
		new SimpleConnection().execute();
	}
	
	
	public void execute() {
		try {
			final UserDefault adminUser = fetchDomainAdmin(Settings.USER_ADMIN_ORG1, Settings.CA);
			
			final HFClient client = instanciateFabricClient();
			client.setUserContext(adminUser);
			
			final Channel channel = fetchChannel(client);
		} 
		catch(final InvalidArgumentException exception) {
			LOG.error("", exception);
		}
	}
	
	protected void requestProposalOnChaincode(final Channel channel) {
		
	}
	
	protected Channel fetchChannel(final HFClient client) {
		Channel channel = null;
		try {
			final Peer peer = client.newPeer("peer0.org1", "grpc://172.31.21.208:30001");
//	        EventHub eventHub = client.newEventHub("eventhub01", "grpc://localhost:7053");
	        final Orderer orderer = client.newOrderer(Settings.ORDERER_ORG1.val("name").get(), Settings.ORDERER_ORG1.val("url").get());
	        channel = client.newChannel(Settings.CHANNEL.val("name").get());
	        channel.addPeer(peer);
//	        channel.addEventHub(eventHub);
	        channel.addOrderer(orderer);
	        channel.initialize();
		} 
		catch(final Exception exception) {
			LOG.error("", exception);
		}
		
		return channel;
	}
	
	/**
	 * TODO
	 * @param userAdmin
	 * @param ca
	 * @return
	 */
	protected UserDefault fetchDomainAdmin(final Settings userAdmin, final Settings ca) {
		
		final UserDefault admin = new UserDefault();
		buildCaClient(ca.val("url").get(), null)
			.ifPresent(caCli -> {
				try {
					final String uName = userAdmin.val("name").get();
					final Enrollment enrollment = caCli.enroll(uName, userAdmin.val("pwd").get());
					admin.setName(uName);
					admin.setDomain(userAdmin.val("domain").get());
					admin.setMspId(userAdmin.val("mspId").get());
					admin.setEnrollment(enrollment);
				} 
				catch(final Exception exception) {
					LOG.error("", exception);
				}
			});
		return admin;
	}
	
	/**
	 * Instantiate a default <code>HFClient</code> class. The instance is configured
	 *  with a default <code>CryptoSuite</code>.
	 * @return The new <code>HFClient</code> instance.
	 */
	protected HFClient instanciateFabricClient() {
		
		final HFClient client = HFClient.createNewInstance();
		instanciateCryptoSuite().ifPresent(crypto -> setupClientCrypto(client, crypto));
		return client;
	}
	
	// Build a Certificate Authoritative client baser on its URL.
	private Optional<HFCAClient> buildCaClient(final String url, final Properties props) {
		
		try {
			final HFCAClient caClient = HFCAClient.createNewInstance(url, props);
			instanciateCryptoSuite().ifPresent(crypto -> caClient.setCryptoSuite(crypto));
			return Optional.of(caClient);
		} 
		catch(final MalformedURLException exception) {
			LOG.error("", exception);
		}
		return Optional.empty();
	}
	
	// Instanciate the crypto suite <code>CryptoSuite</code>.
	private Optional<CryptoSuite> instanciateCryptoSuite() {
		try  {
			final CryptoSuite crypto = CryptoSuite.Factory.getCryptoSuite();
			return Optional.of(crypto);
		} 
		catch(final Exception exception) {
			LOG.error("Can't create cryptography configuration on fabric client.", exception);
		}
		
		return Optional.empty();
	}
	
	 // Setup the cryptography on the <code>HFClient</code> instance.
	private void setupClientCrypto(final HFClient target, final CryptoSuite crypto) {
		try {
			target.setCryptoSuite(crypto);
		} 
		catch(final Exception exception){
			LOG.error("Can't setup cryptography configuration on fabric client.", exception);
		}
	}
}
